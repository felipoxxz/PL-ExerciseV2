﻿namespace Ex25._1.Models
{
    public class FerramentaViewModel
    {
        public int Id { get; set; } // Auto-numeração
        public string Descricao { get; set; }
        public int FabricanteId { get; set; }
    }
}
