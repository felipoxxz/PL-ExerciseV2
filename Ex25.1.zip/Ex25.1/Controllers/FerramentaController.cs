﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using Ex25._1.Models;
using System.Data.SqlClient;

public class FerramentaController : Controller
{
    private readonly string _connectionString;

    // Injeção de dependência da IConfiguration
    public FerramentaController(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection");
    }

    // Método para listar todas as ferramentas
    public IActionResult Index()
    {
        List<FerramentaViewModel> ferramentas = new List<FerramentaViewModel>();

        using (var connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            using (var command = new SqlCommand("sp_GetAllFerramentas", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ferramentas.Add(new FerramentaViewModel
                        {
                            Id = (int)reader["Id"],
                            Descricao = reader["descricao"].ToString(),
                            FabricanteId = (int)reader["FabricanteId"]
                        });
                    }
                }
            }
        }

        return View(ferramentas);
    }

    // Método para exibir o formulário de criação
    public IActionResult Create()
    {
        return View();
    }

    // Método para salvar uma nova ferramenta
    [HttpPost]
    public IActionResult Create(FerramentaViewModel ferramenta)
    {
        if (ModelState.IsValid)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("sp_InsertFerramenta", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Descricao", ferramenta.Descricao);
                    command.Parameters.AddWithValue("@FabricanteId", ferramenta.FabricanteId);

                    command.ExecuteNonQuery();
                }
            }

            return RedirectToAction("Index");
        }

        return View(ferramenta);
    }

    public IActionResult Edit(int id)
    {
        FerramentaViewModel ferramenta = null;

        using (var connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            using (var command = new SqlCommand("sp_GetFerramentaById", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Id", id);

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        ferramenta = new FerramentaViewModel
                        {
                            Id = (int)reader["Id"],
                            Descricao = reader["descricao"].ToString(),
                            FabricanteId = (int)reader["FabricanteId"]
                        };
                    }
                }
            }
        }

        if (ferramenta == null)
        {
            return NotFound(); // Caso não encontre a ferramenta
        }

        return View(ferramenta); // Retorna a view com os dados da ferramenta
    }


    // Método para atualizar a ferramenta
    [HttpPost]
    public IActionResult Edit(FerramentaViewModel ferramenta)
    {
        if (ModelState.IsValid)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("sp_UpdateFerramenta", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", ferramenta.Id);
                    command.Parameters.AddWithValue("@Descricao", ferramenta.Descricao);
                    command.Parameters.AddWithValue("@FabricanteId", ferramenta.FabricanteId);

                    command.ExecuteNonQuery();
                }
            }

            return RedirectToAction("Index"); // Redireciona para a lista de ferramentas após a atualização
        }

        return View(ferramenta); // Se houver erro na validação, retorna a view com os dados
    }

    // Método para deletar
    public IActionResult Delete(int id)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            using (var command = new SqlCommand("sp_DeleteFerramenta", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Id", id);

                command.ExecuteNonQuery();
            }
        }

        return RedirectToAction("Index");
    }
}
