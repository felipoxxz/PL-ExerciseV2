﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Ex28._1.Models;
namespace Ex28._1.Controllers
{
    public class JogosController : Controller
        {
            private readonly JogoContext _context;

            public JogosController(JogoContext context)
            {
                _context = context;
            }

            public async Task<IActionResult> Index()
            {
                return View(await _context.Jogos.ToListAsync());
            }

            public IActionResult Create()
            {
                return View();
            }

            [HttpPost]
            [ValidateAntiForgeryToken]
            public async Task<IActionResult> Create(JogosViewModel jogo)
            {
                if (ModelState.IsValid)
                {
                    _context.Add(jogo);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                return View(jogo);
            }

            public async Task<IActionResult> Edit(int? id)
            {
                if (id == null) return NotFound();

                var jogo = await _context.Jogos.FindAsync(id);
                if (jogo == null) return NotFound();

                return View(jogo);
            }

            [HttpPost]
            [ValidateAntiForgeryToken]
            public async Task<IActionResult> Edit(int id, JogosViewModel jogo)
            {
                if (id != jogo.Id) return NotFound();

                if (ModelState.IsValid)
                {
                    _context.Update(jogo);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                return View(jogo);
            }

            public async Task<IActionResult> Delete(int? id)
            {
                if (id == null) return NotFound();

                var jogo = await _context.Jogos.FindAsync(id);
                if (jogo == null) return NotFound();

                return View(jogo);
            }

            [HttpPost, ActionName("Delete")]
            [ValidateAntiForgeryToken]
            public async Task<IActionResult> DeleteConfirmed(int id)
            {
                var jogo = await _context.Jogos.FindAsync(id);
                if (jogo != null)
                {
                    _context.Jogos.Remove(jogo);
                    await _context.SaveChangesAsync();
                }
                return RedirectToAction(nameof(Index));
            }
    }
}
