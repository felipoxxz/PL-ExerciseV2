﻿using Microsoft.EntityFrameworkCore;

namespace Ex28._1.Models
{
    public class JogosViewModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string? Descricao { get; set; }
        public string? Desenvolvedor { get; set; }
        public decimal Preco { get; set; }
        public DateTime? DataLancamento { get; set; }
    }

    public class JogoContext : DbContext
    {
        public JogoContext(DbContextOptions<JogoContext> options) : base(options) { }

        public DbSet<JogosViewModel> Jogos { get; set; }
    }
}
